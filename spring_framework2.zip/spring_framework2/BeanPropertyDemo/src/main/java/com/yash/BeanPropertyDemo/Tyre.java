package com.yash.BeanPropertyDemo;

public class Tyre {
	private String tyre;

	public String getTyre() {
		return tyre;
	}

	public void setTyre(String tyre) {
		this.tyre = tyre;
	}

	@Override
	public String toString() {
		return "Tyre [tyre=" + tyre + "]";
	}
	
}
