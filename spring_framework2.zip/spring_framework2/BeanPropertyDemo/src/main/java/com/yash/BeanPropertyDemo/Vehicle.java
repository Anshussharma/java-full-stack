package com.yash.BeanPropertyDemo;

public interface Vehicle {
	void drive();
}
