package com.yash.BeanPropertyDemo;

import org.springframework.stereotype.Component;

@Component("Car")
public class Car implements Vehicle {
	
	public void drive() {
		
		System.out.println("Car is running");
		
	}
}
