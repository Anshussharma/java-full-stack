package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.dao.TrackDao;
import com.yash.dto.TrackDto;

@WebServlet("/TrackCourier")
public class TrackCourier extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public TrackCourier() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		int id = Integer.parseInt(request.getParameter("id"));
		PrintWriter out=response.getWriter();
		out.println(id);
		
		TrackDto trackDto=new TrackDto();
		trackDto.setId(id);
		
		TrackDao trackDao=new TrackDao();
		ResultSet set=trackDao.run(trackDto);
		
		HttpSession session=request.getSession();
		session.setAttribute("TrackResultset", set);
		
		response.sendRedirect("showTrackCourier.jsp");
	}

}
