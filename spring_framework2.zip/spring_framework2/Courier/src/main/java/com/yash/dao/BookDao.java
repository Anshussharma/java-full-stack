package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.yash.dto.BookDto;

public class BookDao {
	public boolean run(BookDto bookDto) {
		
		try
		{
			DBConnectivity dc = new DBConnectivity();
			Connection con=dc.getConnectivity();
			String q="insert into courier_details(customer_name,courier_type,pickup_location,destination,weight,amount) values(?,?,?,?,?,?)";
			PreparedStatement st=con.prepareStatement(q);
			
			st.setString(1,bookDto.getName());
			st.setString(2,bookDto.getType());
			st.setString(3,bookDto.getPickup());
			st.setString(4,bookDto.getDestination());
			st.setInt(5,bookDto.getWeight());
			st.setDouble(6,(bookDto.getWeight()*0.25));
			
			st.executeUpdate();
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return false;
	}
}
