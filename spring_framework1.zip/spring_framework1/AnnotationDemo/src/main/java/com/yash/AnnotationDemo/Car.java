package com.yash.AnnotationDemo;

import org.springframework.stereotype.Component;

@Component("Car")
public class Car implements Vehicle {

	public void drive() {
		
		System.out.println("Car is running");
		
	}

}
