package com.yash.ApplicationContextDemo;

public interface Vehicle {
	void drive();
}
