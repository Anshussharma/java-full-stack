package com.yash.ApplicationContextDemo;

public class Car implements Vehicle {

	public void drive() {
		
		System.out.println("Car is running");
		
	}

}
