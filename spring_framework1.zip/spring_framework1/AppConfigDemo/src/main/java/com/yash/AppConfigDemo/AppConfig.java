package com.yash.AppConfigDemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.yash.AppConfigDemo")
public class AppConfig {

//	@Bean
//	public Samsung getPhone()
//	{
//		return new Samsung();
//	}
//	
//	@Bean
//	public Processor getProcessor()
//	{
//		return new Processor();
//	}
}
