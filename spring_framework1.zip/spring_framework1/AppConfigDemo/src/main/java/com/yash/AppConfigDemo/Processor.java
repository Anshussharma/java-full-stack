package com.yash.AppConfigDemo;

import org.springframework.stereotype.Component;

@Component
public class Processor {

	void process()
	{
		System.out.println("In the Process..");
	}
}
