package com.yash.AppConfigDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class Samsung {
	
	@Autowired
	Processor p;
	
	public Processor getP() {
		return p;
	}

	public void setP(Processor p) {
		this.p = p;
	}

	public void config()
	{
		System.out.println("Octa Core");
		p.process();
	}
}
