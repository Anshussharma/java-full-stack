package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController {

	@RequestMapping("/home")
	public String home(Model model) 
	{
		model.addAttribute("name", "Hritik");

		ArrayList<String> list = new ArrayList<String>();
		list.add("Hritik");
		list.add("Manesh");
		list.add("Sunil");
		list.add("Hardik");
		list.add("Shruti");
		
		model.addAttribute("list", list);
		return "index";

	}
}
