package com.yash.aopimpl.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {

	@Before("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
	public void printBefore() {
		System.out.println("Payment Initilaized");
	}

	@After("com.yash.aopimpl.aspect.MyAspect.printPointcut()")
	public void printAfter() {
		System.out.println("Payment Completed");
	}
	
	@Pointcut("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
	public void printPointcut() {
	}
}