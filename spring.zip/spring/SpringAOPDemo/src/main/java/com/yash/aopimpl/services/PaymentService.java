package com.yash.aopimpl.services;

public interface PaymentService {

	public void makePayment();

}