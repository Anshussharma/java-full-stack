import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App {

	public static void main(String[] args) {
		System.out.println("Welcome");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e = (Employee) context.getBean("employee");
		System.out.println(e);
		Resource resource = new ClassPathResource("applicationcontext.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		String e1 = (String) factory.getBean("employee1");
		System.out.println(e1);

		Employee e2 = (Employee) context.getBean("ep");
		e2.destroy();
		ConfigurableApplicationContext cap = new ClassPathXmlApplicationContext("applicationcontext.xml");
		// Employee e3 = (Employee) cap.getBean("ep");
		// System.out.println(e3);
		cap.close();
	}

}
