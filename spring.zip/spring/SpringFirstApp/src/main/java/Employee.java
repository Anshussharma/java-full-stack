import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Employee implements ApplicationContextAware,BeanNameAware {
	private String name;
	private String email;
	private ApplicationContext context =null;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static String getName1() {
		return "Hritik";
	}

	@Override
	public String toString() {
		return "Hello: " + name+ " Email: "+email;
	}

	public void setBeanName(String beanName) {
		System.out.println("Bean name is: "+beanName);
		
	}

	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context=context;
		
	}
	public void init() 
    {
        System.out.println(
            "Bean HelloWorld has been "
            + "instantiated and I'm "
            + "the init() method");
    }
 
	@PreDestroy
    public void destroy() 
    {
        System.out.println(
            "Container has been closed "
            + "and I'm the destroy() method");
    }
}
	

