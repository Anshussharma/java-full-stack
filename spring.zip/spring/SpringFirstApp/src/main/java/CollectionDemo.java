import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionDemo {

	private List emp1;
	private Set emp2;
	private Map emp3;

	public List getEmp1() {
		return emp1;
	}

	public void setEmp1(List emp1) {
		this.emp1 = emp1;
	}

	public Set getEmp2() {
		return emp2;
	}

	public void setEmp2(Set emp2) {
		this.emp2 = emp2;
	}

	public Map getEmp3() {
		return emp3;
	}

	public void setEmp3(Map emp3) {
		this.emp3 = emp3;
	}

	@Override
	public String toString() {
		return "CollectionDemo [emp1=" + emp1 + ", emp2=" + emp2 + ", emp3=" + emp3 + "]";
	}
}
