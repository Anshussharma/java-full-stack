import org.springframework.beans.factory.annotation.Autowired;

public class Emp {
	@Autowired
	private Address address;

	public Address getAddress() {
		System.out.println("Inside the Getter");
		return address;
	}

	@Autowired
	public void setAddress(Address address) {
		this.address = address;
		System.out.println("Inside the Setter");
	}

	@Autowired
	public Emp(Address address) {
		super();
		this.address = address;
		System.out.println("Inside the constructor");
	}
}
