package springmvc.controller;

import javax.validation.constraints.Size;

public class Employee {
	private String name;
	@Size(min = 4, message = "more than 4 characters required")
	private String pass;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
}
