const quizData = [
    {
      question: "What is most dangerous animal?",
      a: "Dog",
      b: "Cat",
      c: "Wolf",
      d: "Tiger",
      correct: "d",
    },
    {
      question: "Choose 1 of the following. What you should do in your free time?",
      a: "Gaming",
      b: "Reading",
      c: "Netflix",
      d: "Sleep",
      correct: "b",
    },
    {
      question: "Chose your favourite season of the year.",
      a: "Winters",
      b: "Summers",
      c: "Monsoon",
      d: "Any season is good for me",
      correct: "a",
    },
    {
      question: "Choose the color not in rbg.",
      a: "red",
      b: "pink",
      c: "blue",
      d: "green",
      correct: "b",
    },
    {
      question: "Choose your favourite food.",
      a: "Pizza",
      b: "Butter Paneer",
      c: "Biryani",
      d: "I like to drink not eat",
      correct: "a",
    },
    {
      question: "Choose the most suitable",
      a: "black is dark",
      b: "white is dull",
      c: "green is color of sky",
      d: "water is pink",
      correct: "a",
    },
]

const quiz = document.getElementById("quiz");
const answerEls = document.querySelectorAll(".answer");
const questionEl = document.getElementById("question");
const a_text = document.getElementById("a_text");
const b_text = document.getElementById("b_text");
const c_text = document.getElementById("c_text");
const d_text = document.getElementById("d_text");
const nextButton = document.getElementById("submit");

let currentQuiz = 0

loadQuiz();

function loadQuiz(){

    deselectAnswer();

    currentQuizData = quizData[currentQuiz]
    questionEl.innerText = currentQuizData.question; 
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b; 
    c_text.innerText = currentQuizData.c; 
    d_text.innerText = currentQuizData.d; 
}

function deselectAnswer() {
    answerEls.forEach((answerEl) => {
        console.log(answerEl)
      answerEl.checked = false;
    });
  }


function getSelected(){
    let answer;

    answerEls.forEach((answerEl) => {
        if (answerEl.checked){
            answer = answerEl.id;
        }
    });
    return answer
}

let score = 0;

nextButton.addEventListener("click", () => {

    const answer = getSelected();
  
    if (answer) {
      if (answer === quizData[currentQuiz].correct) {
        score++;
      }
    }

    currentQuiz++;


    if (currentQuiz < quizData.length) {
      loadQuiz();
    } else {
        if (score > 3){
            quiz.innerHTML = `
      <h2>You answered ${score} out of ${quizData.length} correctly. You passed, Congrats.</h2>
       <button onclick="location.reload()">Try Again?</button>`;
        }
        else{
      quiz.innerHTML = `
      <h2>You answered ${score} out of ${quizData.length} correctly. You failed.</h2>
       <button onclick="location.reload()">Try Again?</button>`;
    }}

  });