package com.anshu1;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

//import org.apache.tomcat.util.http.parser.Cookie;
public class Sevlet4 extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	   {
		
		Cookie[] c= req.getCookies();
		
		
		   PrintWriter out= res.getWriter();
		   out.println("name : "+c[1].getValue());
		   out.println("password : "+c[2].getValue());
	   }
}
