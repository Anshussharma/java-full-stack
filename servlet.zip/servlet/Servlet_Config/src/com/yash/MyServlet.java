package com.yash;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class MyServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	   {
		   String name= req.getParameter("username");
		   String password= req.getParameter("password");
		   
		   
		 Cookie c1 = new Cookie("name", name);
		 Cookie c2 = new Cookie("password", password);
		 PrintWriter out= res.getWriter();
		 out.println("hello "+name);
		  res.addCookie(c1);
		  res.addCookie(c2);
		   res.sendRedirect("srv4");
		 
	   }
}
