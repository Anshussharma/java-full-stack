package com.anshu;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
/*import javax.servlet.RequestDispatcher;*/
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddServlet extends HttpServlet {
  
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
   {
	   int i= Integer.parseInt(req.getParameter("1st-nmbr"));
	   int j= Integer.parseInt(req.getParameter("2nd-nmbr"));
	   int k=i+j;
	   res.getWriter().println(k);
	   req.setAttribute("k", k);
	   
	   RequestDispatcher rd=req.getRequestDispatcher("sq");
	   rd.forward(req, res);
   }
}
