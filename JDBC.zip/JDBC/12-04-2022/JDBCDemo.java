import java.sql.*;
class JDBCDemo
{
	public static void main(String [] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash_technologies","root","root");
			
			if(con!=null)
			{
				System.out.println("Connection is created..");
			}
			else
			{
				System.out.println("Connection is failed..");
			}
			
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery("select * from employee");
			
			while(set.next())
			{
				System.out.println("ID: "+set.getInt("empID")+", Name: "+set.getString("name"));
			}
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}