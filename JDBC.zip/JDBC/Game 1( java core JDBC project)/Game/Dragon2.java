package Game;

public class Dragon2 extends Dragon { //inheritance
	private int life;   //concept of encapsulation
    private boolean fly;

    public Dragon2(String power, int life) {
        super(power, life);
        this.life = life;
        
    }
    public void setFly(boolean fly) {
    	this.fly = fly;
    }
    
    public void damageByGun1() {   //(over-riding) polymorphism
       
			if(fly){
             
			    this.life -= 15;
			
		
            if(this.life <=0) 
            System.out.println("Dragon is flying. Got hit by gun 1. Dragon's life is reduced by 15." +
                    "life is "+ this.life);
        } if(!fly){
           
			   this.life -= 20;
			
            if(this.life <=0) this.life = 0;
            System.out.println("Dragon is on the ground. Got hit by gun 1. Life is reduced by 20." +
                    "life is "+ this.life);
        }
        if(this.life == 0){
            System.out.println("Dragon is dead");
		 }
		
    }

    
    public void damageByGun2() {   //(over-riding )polymorphism
      
		   if(fly){
			   
            this.life -= 20;
			
            if(this.life <=0) this.life = 0;
            System.out.println("Dragon is flying. Got hit by gun 2. Life is reduced by 20." +
                    "life is "+ this.life);
        }
		   if(!fly){
            this.life -= 40;
			
            if(this.life <=0) this.life = 0;
            System.out.println("Dragon is on the ground. Got hit by gun 2. Life is reduced by 40." +
                    "life is "+ this.life);
        }
        if(this.life == 0){
            System.out.println("Dragon is dead . You Win!!");
        }
	   
	   }
   
    public int getLife() { //concept of encapsulation
        return life;
    }

    public void setLife(int life) { //concept of encapsulation
        this.life = life;
    }
    
    public void rest() { //inheritance 
        super.rest();
    }
}

