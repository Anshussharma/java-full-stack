import java.sql.*;
import java.io.*;
class StoreTextFileInDB
{
	public static void main(String [] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash_technologies","root","root");
			
			PreparedStatement ps=con.prepareStatement("insert into text_file(text) values(?)");
			
			FileInputStream f=new FileInputStream("Yash.txt");
			
			ps.setBinaryStream(1,f);
			ps.executeUpdate();
			
			System.out.println("Insert Successfully..");
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}