import java.sql.*;
class PreparedStatementDemo
{
	public static void main(String [] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash_technologies","root","root");
			
			PreparedStatement ps=con.prepareStatement("insert into employee(empID,name) values(?,?)");
			
			ps.setInt(1,1003);
			ps.setString(2,"Yash");
			ps.executeUpdate();
			
			System.out.println("Insert Successfully..");
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}