import java.sql.*;
import java.io.*;
class StoreImagesInDB
{
	public static void main(String [] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash_technologies","root","root");
			
			PreparedStatement ps=con.prepareStatement("insert into images(pic) values(?)");
			
			FileInputStream f=new FileInputStream("Img.png");
			
			ps.setBinaryStream(1,f);
			ps.executeUpdate();
			
			System.out.println("Insert Successfully..");
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}