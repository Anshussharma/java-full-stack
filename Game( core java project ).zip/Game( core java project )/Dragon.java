package Game;
public class Dragon {
    
    private String power;
    private int life;

    public Dragon(String power, int life) {
 
        this.power = power;
        if(life < 0 || life > 100){
            this.life = 100;
        }else this.life = life;
    }

    public void damageByGun1(){
       try{
		   this.life -= 30;
		if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
		}
        if(this.life ==0){
            this.life = 0;
        }
        System.out.println("Got hit by gun 1. Dragon's life is reduced by 30" +
                ". life is "+ this.life);
        if(this.life == 0){
            System.out.println(" dragon is dead");
        }
	   }
	   catch(ArithmeticException e){
		   e.printStackTrace();
	   }
    }
    public void damageByGun2(){
        this.life -= 50;
		try{
			if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
		}
        if(this.life ==0){
            this.life = 0;
        }
        System.out.println("Got hit by gun 2. life is reduced by 50" +
                ". life is "+ this.life);
        if(this.life == 0){
            System.out.println("dragon is dead");
        }
		}
		 catch(ArithmeticException e){
		   e.printStackTrace();
	   }
    }

    public void rest(){
		try{
			if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
		}
		}
		catch(ArithmeticException e){
		   e.printStackTrace();
	   }
		
        if(this.life == 0 ) System.out.println("Dragon is dead. You win");
        else{
            this.life = 100;
            System.out.println("life is "+this.life);
        }
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }
}