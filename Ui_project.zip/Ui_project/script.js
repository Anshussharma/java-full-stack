$(document).ready(function(){
    
    $("#img1").click(function(){
        $("#abt1").hide();
    });
});