//this function wil be called either success or failure happend
function show(msg)
{
console.log(msg);
}
let mypromise= new Promise(function(myResolve,myReject){
	let x=testusername("ssunil@gmail.com","1232#@");
	if (x==1)
		 myResolve("Your welcome");
	 else if(x==0)
		  myReject("username did not matched with password");		
});

mypromise.then(function(value){show(value);},function(error){show(error);});

function testusername(un,pass)
{
	if(un=="sunil@gmail.com" && pass=="1232#@")
		return 1;
	else  
		return 0;		 
}