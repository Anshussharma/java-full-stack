function show(msg)
{
console.log(msg);
}
let myPromise=new Promise(function(myResolve,myReject){



let x=testusername("sunil@gmail.com","1232#@");
if(x==1)
myResolve("Your Welcome");
else if(x==0)
myReject("userName did not matched with pass");
else if (x==2)
myReject("no account found");



});



myPromise.then(function(value){show(value);},function(error){show(error);});



function testusername(string)
{
if(un=="sunil@gmail.com" && pass=="1232#@")
return 1;
else if(un!="sunil@gmail.com" && pass!="1232#@")
return 2;
else if(un!="sunil@gmail.com" || pass!="1232#@")
return 0;
}