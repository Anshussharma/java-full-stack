function show(msg){
    console.log(msg);
    }
    
    
    let myPromise = new Promise(function(myResolve,myReject){
    let x = checkArmstrong("371");
    if(x == 0)
    myResolve("An Armstrong number");
    else if(x ==1 )
    myReject("Not an Armstrong number");
    });
    myPromise.then(function(value){show(value);},
    function(error){show(error);}
    );
    function checkArmstrong(str){
        const len = str.length;
        var total=0;
        for(let i=0;i<len;i++){ 
            total+= str[i]*str[i]*str[i];
        } 
        if( total==parseInt(str))
        {
            return 0;
        }
        return 1;
    }