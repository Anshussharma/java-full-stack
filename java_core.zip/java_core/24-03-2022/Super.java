class Parent
{
	String s="Parent class variable";
	
	Parent()
	{
		System.out.println("Parent class constructor");
	}
	
	void show()
	{
		System.out.println("Parent class method");
	}
}
class Super extends Parent
{   
	String s="Child class variable";
	
	{
		System.out.println("Child class constructor");
	}
	void show()
	{
		System.out.println("Child class Method");
	}
	void display()
	{
		System.out.println(s);
		show();
		System.out.println(super.s);
		super.show();
	}
	public static void main(String [] args)
	{
		Super s=new Super();
		s.display();
	}
}