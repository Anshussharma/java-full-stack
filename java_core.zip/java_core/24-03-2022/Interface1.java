interface Product
{
	void type();
}

interface Appliance extends Product
{
	void power();
}

class Interface1 implements Appliance
{
	public void power()
	{
		System.out.println("2100 Watts");
	}
	
	public void type()
	{
		System.out.println("Electronic");
	}
	public static void main(String [] args)
	{
		Interface1 a=new Interface1();
		a.power();
		a.type();
	}
}