class Person{
    String name;
    String dob;
  	void walks(){
		System.out.println("Person walks");
	}		
}
class Teacher extends Person{
	int salary;
	String sub;
    	void walks(){
		System.out.println("Teacher Walks to the class");
	}	
	public static void main(String [] args){
	Person p=new Person();
	Teacher t=new Teacher();
	Student s =new Student();
	ClgStudent c=new ClgStudent();
	p.name="Person";
	p.dob="09/05/2000";
	System.out.println(p.name+" "+ p.dob +" ");
	p.walks();
	t.name="Teacher";
	t.dob="10/05/2000";
	t.salary=45000;
	System.out.println(t.name+" "+t.dob+" "+ t.salary +" ");
	t.walks();
	s.name="Student";
	s.dob="11/05/2000";
	s.stdid=0101;
	System.out.println(s.name+" "+s.dob+" "+s.stdid +" ");
	s.walks();
	c.name="Clg Student";
	c.dob="12/05/2000";
	c.stdid=0102;
	c.clg_name="UIT RGPV";
	c.year="IV";
	System.out.println(c.name+" "+c.dob+" "+c.clg_name+" "+c.year+" "+c.stdid+" ");
	c.walks();
	
	}
}
class Student extends Person{
	int stdid;
		void walks(){
		System.out.println("Student walks in the class");
	}	
}
class ClgStudent extends Student{
	String clg_name;
	String year;
}