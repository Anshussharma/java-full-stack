class Author{
    private String name;
    private String email;
    private char gender;
  	public void setter(String name,String email,char gender){
		this.name=name;
		this.email=email;
		this.gender=gender;
	}
	public String getter1(){
		return name+" "+email+" "+String.valueOf(gender);
	}
}
class Book extends Author{
	private String name;
	private double price;
	private int qtylnstock;
    
	
	Book(String name,double price,int qtylnstock){
		
		this.name=name;
		this.price=price;
		this.qtylnstock=qtylnstock;
	}
	String getter(){
		String s=name+" ";
		return s;
	}
	String getter2(){
		return String.valueOf(price)+" "+String.valueOf(qtylnstock);
	}
	
	
	public static void main(String [] args){
		Author a=new Author();
		//String s2=a.getter();
		Book b=new Book("book's name",234.5,10);
		b.setter("Author's name","author@yash.com",'M');
	
		//b.setter("book","Author's name","author@yash.com",'M',234.5,10);
		System.out.println(b.getter());
		System.out.println(b.getter1());
		System.out.println(b.getter2());
	}

	
}
