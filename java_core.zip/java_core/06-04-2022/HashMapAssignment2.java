import java.util.Properties;
import java.util.Iterator;
import java.util.Set;
import java.util.Map;

class HashMapAssignment2
{
	public static void main(String [] args)
	{
		Properties p=new Properties();
		p.setProperty("Madhya Pradesh","Bhopal");
		p.setProperty("Andhra Pradesh","Hyderabad");
		p.setProperty("Assam","Dispur");
		
		Set set=p.entrySet();
		Iterator i=set.iterator();
		
		while(i.hasNext())
		{
			Map.Entry e=(Map.Entry)i.next();
			System.out.println("State: "+e.getKey()+", Capital: "+e.getValue());
		}
		
	}
}