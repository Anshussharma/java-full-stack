import java.util.HashMap;
import java.util.Iterator;
import java.util.Collections;
import java.util.ArrayList;

class HashMapSorting
{
	public static void main(String [] args)
	{
		HashMap<Integer, String> hm = new HashMap<>();
		
		hm.put(10, "Indore");
		hm.put(20, "Bhopal");
		hm.put(30, "Jabalpur");
		hm.put(40, "Mumbai");
		
		for(int i : hm.keySet()){
			System.out.println("Key : " + i + ", " + "Value : " + hm.get(i));
		}
		
		ArrayList<Integer> al = new ArrayList<>();
		for(Integer i : hm.keySet()){
			al.add(i);
		}
		System.out.println("\n");
		Collections.sort(al);
		for(int i : al){
			System.out.println("Key : " + i + ", Value: " + hm.get(i));
		}
		
		ArrayList<String> al2 = new ArrayList<>();
		for(String s : hm.values()){
			al2.add(s);
		}
		System.out.println("\n");
		Collections.sort(al2);
		for(String s : al2){
			System.out.println(s);
		}
		
	}
}
