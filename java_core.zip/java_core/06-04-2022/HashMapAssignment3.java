import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner; 

class HashMapAssignment3
{
	public static void main(String [] args)
	{
		HashMap<String,Integer> hm=new HashMap<String,Integer>();
		hm.put("Anshu", 10);
		hm.put("Yash", 20);
		hm.put("Soum", 30);
		hm.put("Manesh", 40);
		
		Scanner sc=new Scanner(System.in);
		
		int count=0;
		
		System.out.println("Enter a Name to find: ");
		String value=sc.next();
		
		Iterator i2=(hm.keySet()).iterator();
		
		while(i2.hasNext())
		{
			if(((String)i2.next()).equals(value))
			{
				System.out.println("Match found");
				break;
			}
			count++;
			if (count==hm.size())
			{
				System.out.println("No Match found\n");
			}
		}
		
		Iterator i=(hm.values()).iterator();
		System.out.println("Enter a Phone No. to find: ");
		int key=sc.nextInt();
		
		count=0;
		
		while(i.hasNext())
		{
			if(((int)i.next())==key)
			{
				System.out.println("Match found");
				break;
			}
			count++;
			if (count==hm.size())
			{
				System.out.println("No Match found");
			}
		}
	}
}