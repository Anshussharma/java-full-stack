import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner; 

class HashMapAssignment1
{
	public static void main(String [] args)
	{
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		hm.put(10, "Indore");
		hm.put(20, "Bhopal");
		hm.put(30, "Jabalpur");
		hm.put(40, "Mumbai");
		
		Iterator i=(hm.keySet()).iterator();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a key to find: ");
		int key=sc.nextInt();
		
		int count=0;
		
		while(i.hasNext())
		{
			if(((int)i.next())==key)
			{
				System.out.println("Match found\n");
				break;
			}
			count++;
			if (count==hm.size())
			{
				System.out.println("No Match found\n");
			}
		}
		
		count=0;
		
		System.out.println("Enter a Value to find: ");
		String value=sc.next();
		
		Iterator i2=(hm.values()).iterator();
		
		while(i2.hasNext())
		{
			if(((String)i2.next()).equals(value))
			{
				System.out.println("Match found");
				break;
			}
			count++;
			if (count==hm.size())
			{
				System.out.println("No Match found\n");
			}
		}
	}
}