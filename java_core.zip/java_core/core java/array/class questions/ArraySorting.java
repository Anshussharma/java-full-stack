class ArraySorting{

public static void main(String [] args){

 int[] arr=new int[] {5,7,2,9,3};
		
for(int i=0; i<5-1; i++) {
int min=i;
			
for(int j=i; j<5; j++) {
				
if(arr[j]<arr[min]) {
min=j;
 }
  }
			
if(arr[i]>arr[min]) {
				
int temp=arr[i];
				
arr[i]=arr[min];
				
arr[min]=temp;
			
}
		
 }
		
for(int i=0;i<5;i++) {
			
System.out.println(arr[i]);
		
   }
  }

}
