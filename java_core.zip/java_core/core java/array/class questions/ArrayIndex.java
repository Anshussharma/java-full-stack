class ArrayIndex{

public static void main(String [] args){

 int[] a= {10,37,20,64,85,02,84};
 boolean search=false;
 int num=22;
for(int i=0;i<a.length;i++){
  
  if(a[i]==num){
    System.out.println(i);
    search=true;
    }
 }
if(search==false){
System.out.println("-1");
}

//System.out.println("the max value of the array is: "+ min);
//System.out.println("the average of the array is: "+ avg);

}
}