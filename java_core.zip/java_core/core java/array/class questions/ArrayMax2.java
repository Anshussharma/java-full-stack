class ArrayMax2{

public static void main(String [] args){

 int[] a= {10,37,20,64,85,02,84};
 boolean search=false;
 int max1=0;
 int max2=0;
for(int i=0;i<a.length;i++){
  
  if(a[i]>max1){
    max1=a[i];
    }
  }
for(int i=0;i<a.length;i++){
   if(a[i]>max2 && a[i]!=max1){
    max2=a[i];
    }
  }


System.out.println("the first two max value of the array are: "+ max1+" "+max2);
//System.out.println("the average of the array is: "+ avg);

}
}