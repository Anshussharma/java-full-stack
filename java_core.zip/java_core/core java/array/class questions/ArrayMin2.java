class ArrayMin2{

public static void main(String [] args){

 int[] a= {10,37,20,64,85,02,84};
 boolean search=false;
 int min1=a[0];
 int min2=a[0];
for(int i=0;i<a.length;i++){
  
  if(a[i]<min1){
    min1=a[i];
    }
  }
for(int i=0;i<a.length;i++){
   if(a[i]<min2 && a[i]!=min1){
    min2=a[i];
    }
  }


System.out.println("the first two max value of the array are: "+ min1+" "+min2);
//System.out.println("the average of the array is: "+ avg);

}
}