class Array{
//static int step=1;
public static void main(String [] args){
 //int a=Integer.parseInt(args[0]);
 int[][] a= {{10,20,30},{40,50}};

int total=0;
int count=0;
for(int i=0;i<a.length;i++){
  for(int j=0;j<a[i].length;j++){
     total=total+a[i][j];
     ++count;
    }
 }
int avg= total/count;
System.out.println("the sum of the array is: "+ total);
System.out.println("the average of the array is: "+ avg);

}
}