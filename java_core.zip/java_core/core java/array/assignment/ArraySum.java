class ArraySum{

public static void main(String [] args){

 int[] a= {10,3,2,6,64,7,8,4};
 //boolean search=false;
 //int min1=a[0];
 int sum=0;
int indx1=0; int indx2=0;
for(int i=0;i<a.length;i++){
   if(a[i]==6){
     indx1=i;
   }
   if(a[i]==7){
     indx2=i;
   }
  }
if(indx1<indx2){
  for(int i=indx1; i<=indx2;i++){
    a[i]=0;
   }
 }
for(int i=0;i<a.length;i++){
 sum=sum+a[i];
}

  


System.out.println("sum is "+ sum);
//System.out.println("the average of the array is: "+ avg);

}
}