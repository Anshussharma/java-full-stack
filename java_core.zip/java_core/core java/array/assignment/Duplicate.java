class Duplicate{

public static void main(String [] args){

 int[] a= {10,37,20,64,85,20,84,20};
 
for(int i=0;i<a.length;i++){
  int num=a[i];
  for(int j=i+1;j<a.length;j++){
  int value=a[i];
  if(a[j]==value){
    a[j]=0;
    }
   }
 if(a[i]!=0){
 System.out.print(a[i]+" ");
}
  }

  
}
}