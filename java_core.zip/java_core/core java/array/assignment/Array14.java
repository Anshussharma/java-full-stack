class Array14{

public static void main(String [] args){

 int[] a= {1,4,2,4};
 boolean search=false;
 //int min1=a[0];
 int sum=0;
int indx1=0; int indx2=0;
for(int i=0;i<a.length;i++){
   if(a[i]==1 || a[i]==4){
     search=true;
   }
   else{
    search=false;
    break;
 }
   
  }
System.out.println(search);
}
}