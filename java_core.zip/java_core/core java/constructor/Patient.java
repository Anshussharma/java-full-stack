
class Patient{
	String patient_name;
	double height;
	double weight;
	double bmi;
	Patient(String patient_name, double height, double weight)
		{
			this.patient_name=patient_name;
			this.height=height;
			this.weight=weight;
		}
	double computeBMI(){
	  bmi=weight/(height*height);
	  return bmi;
		//System.out.println(patient_name+"'s BMI is: "+bmi);	
		}
	public static void main(String [] args){
		
		Patient p=new Patient("akansha",1.56,60);
		System.out.println(p.computeBMI());
		
	}
}