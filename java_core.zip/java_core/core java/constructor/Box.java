
class Box{
	int width,height,depth;
	 Box(int width,int height,int depth)
		{
			this.width=width;
			this.height=height;
			this.depth=depth;
		}
	void volume(){
		int v=width*height*depth;
		System.out.println("volume of the box is: "+v);	
		}
	public static void main(String [] args){
		
		Box b=new Box(3,4,5);
		b.volume();
		
	}
}