class Constructors{
	String name;
	int empid;
	Constructors(String name,int empid){
	System.out.println("arg constructor running");
			this.name=name;
		this.empid=empid;
		
	}
	Constructors(){
	System.out.println("no arg constructor running");	
	}
	public static void main(String [] args){
		Constructors e1=new Constructors("anshu",101);
		Constructors e2=new Constructors();
		e2.name="yash";
		e2.empid=102;
		System.out.println(e1.name+" "+e1.empid);
		System.out.println(e2.name+" "+e2.empid);
	}
}