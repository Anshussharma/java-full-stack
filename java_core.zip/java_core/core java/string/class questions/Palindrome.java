class Palindrome{
public static void main(String []args){
 int n=Integer.parseInt(args[0]);
 String s=String.valueOf(n);
 int m= s.length()/2;
boolean isit=false;
 for(int i=0;i<=m;i++){
if(s.charAt(i)==s.charAt(n-i){
  isit=true;
}
else{
isit= false;
break;
}
}
System.out.println(isit);
}
}