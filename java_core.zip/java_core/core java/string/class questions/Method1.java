class Method1
{
public static void main(String [] args)
{
String s1= "anshu";
String s2="Anshu";
if(s1.isEmpty()){
System.out.println("it is empty");
}
else {
System.out.println("is not empty");
}

if(s1.equals(s2)){
System.out.println("strings are same");
}
if(s1.equalsIgnoreCase(s2)){
System.out.println("strings are same ignoring the cases");
}
else {
System.out.println("strings are not same");
}
System.out.print(s1.compareTo(s2));
 

}
 
}