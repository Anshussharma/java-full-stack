class StringMix{
public static void main(String[] args){
String a="hello";
		 String b="Anshu";
		 String c="";
		 for(int i=0;i<a.length();i++){
		   
		      c=c+String.valueOf(a.charAt(i));
		      c=c+String.valueOf(b.charAt(i));
		  }
		  System.out.println(c);
	}
}

