import java.io.FileReader; 
public class PatternMatchingAssignment2 
{  
	public static void main(String[] args) throws Exception
	{  
		FileReader f=new FileReader("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/11-04-2022/Yash.txt");
		String s="";
		int i;
		while((i = f.read()) != -1)
		{
			if(i!=13)
			{
				s=s.concat(String.valueOf((char)i));
			}
			else
			{
				s=s.concat(" --New Line");
			}
		}
		s=s.concat(" --New Line");
		System.out.println(s);
	}  
}  