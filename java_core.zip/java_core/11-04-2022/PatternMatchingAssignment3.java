import java.util.Scanner;
class PatternMatchingAssignment3
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter the string: ");
		String s=sc.nextLine();
		String digits = s.replaceAll("[^0-9]", "");
		digits = digits.replaceAll("", ",");
		System.out.println(digits);
	}
}