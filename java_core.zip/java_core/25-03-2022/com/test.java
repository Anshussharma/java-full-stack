package com;
import com.automobile.twowheeler.Hero;
public class test
{
	public static void main(String [] args)
	{
		Hero hero=new Hero();
		System.out.println(hero.getSpeed());
		hero.radio();
	}
}