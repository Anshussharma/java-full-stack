package com.automobile.twowheeler;
import com.automobile.*;

public class Hero extends Vehicle
{
	public int getSpeed()
	{
		int speed=80;
		return speed;
	}
	
	public void radio()
	{
		System.out.println("Radio facility provider.");
	}
	
	public String getName()
	{
		return "Hello";
	}
}