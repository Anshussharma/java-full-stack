//import myPackage
package myPackage;
public class Start
{
	public void display()
	{
		System.out.println("I am in mypackage");
	}
}
