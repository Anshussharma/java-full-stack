import myPackage.*;

class Package
{
	public static void main(String [] args)
	{
		Start s=new Start();
		s.display();
	}
}