import javax.swing.*;

class InputByJOptionPane
{
	public static void main(String [] args)
	{
		JFrame f=new JFrame();
		String name=JOptionPane.showInputDialog(f,"Enter Name: ");
		JOptionPane.showMessageDialog(f,"Hello "+name);
		System.exit(0);
	}
}