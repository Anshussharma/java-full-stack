class help
{
	void display()
	{
		System.out.println("I am Parent");
	}
}

class Overriding extends help
{
	void display()
	{
	  System.out.println("I am child");	
	}
	
	public static void main(String [] args)
	{
		Overrinding s =new Overrinding();
		s.display();
	}
}