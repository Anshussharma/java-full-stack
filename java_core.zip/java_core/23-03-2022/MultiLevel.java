class GrandParent
{
	void show()
	{
		System.out.println("I am GrandParent");
	}
}
class Parent extends GrandParent
{
	void show1()
	{
		System.out.println("I am Parent");
	}
}

class MultiLevel extends Parent
{
	public static void main(String [] args)
	{
		MultiLevel s=new MultiLevel();
		s.show();
		s.show1();
	}
}
