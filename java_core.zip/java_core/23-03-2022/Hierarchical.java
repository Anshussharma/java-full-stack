class Parent
{
	void show()
	{
		System.out.println("I am Parent");
	}
}
class Child2 extends Parent
{
	
}

class Hierarchical extends Parent
{
	public static void main(String [] args)
	{
		Hierarchical s=new Hierarchical();
		Child2 c=new Child2();
		s.show();
		c.show();
	}
}
