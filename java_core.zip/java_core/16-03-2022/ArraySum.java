class ArraySum
{
	public static void main(String [] args)
	{
		int[] arr=new int[]{10,20,30,40,50,60};
		int sum=0;
		for(int a:arr)
		{
			sum=sum+a;
		}
		System.out.println(sum+" "+sum/arr.length);
		int[][] arr1=new int[][]{{10,20},{30,40},{50,60}};
		sum=0;
		int length=0;
		for(int b[]:arr1)
		{
			for(int c:b)
			{
				sum=sum+c;
				length++;
			}
		}
		System.out.println(sum+" "+sum/length);
	}
}