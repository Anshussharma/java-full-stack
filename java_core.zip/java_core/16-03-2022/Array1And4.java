class Array1And4
{
	public static void main(String [] args)
	{
		int[] arr=new int[]{1,4,1,4,1,4};
		for(int a=0;a<arr.length;a++)
		{
			if(arr[a]==1||arr[a]==4)
			{
				if((arr.length-1)==a)
				System.out.println("True");
			}
			else
			{
				System.out.println("False");
				break;
			}
		}
		
	}
}