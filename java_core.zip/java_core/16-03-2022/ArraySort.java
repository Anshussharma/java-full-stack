class ArraySort
{
	public static void main(String [] args)
	{
		int[] arr=new int[]{10,60,20,40,30,50};
		int c=0;
		for(int a=0;a<arr.length;a++)
		{
			for(int b=a;b<arr.length;b++)
			{
				if(arr[a]>arr[b])
				{
					c=arr[a];
					arr[a]=arr[b];
					arr[b]=c;
				}
			}
		}
		for(int d:arr)
		{
			System.out.print(d+" ");
		}
	}
}