class ArrayLargest3D{
	public static void main(String [] args)
	{
		int max=0;
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		int num3=Integer.parseInt(args[2]);
		int num4=Integer.parseInt(args[3]);
		int num5=Integer.parseInt(args[3]);
		int num6=Integer.parseInt(args[3]);
		int num7=Integer.parseInt(args[3]);
		int num8=Integer.parseInt(args[3]);
		int num9=Integer.parseInt(args[3]);
		
		int[][][] arr=new int[][][]{{{num1},{num2},{num3}},{{num4},{num5},{num6}},{{num7},{num8},{num9}}};
		
		for(int a=0;a<arr.length;a++)
		{
			for(int b=a+1;b<arr.lenght;b++)
			{
				for(int c=b+1;c<arr.length;c++)
				{
					if(max<arr[c])
					{
						max=arr[c];
					}
				}
			}
		}
	}
}