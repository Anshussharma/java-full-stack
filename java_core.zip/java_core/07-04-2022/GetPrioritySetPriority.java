class GetPrioritySetPriority extends Thread
{
	public void run()
	{
		System.out.println("I am Thread");
	}
	
	public static void main(String [] args)
	{
		GetPrioritySetPriority t=new GetPrioritySetPriority();
		
		System.out.println(t.getPriority());
		
		t.setPriority(MIN_PRIORITY);
		System.out.println(t.getPriority());
		
		t.setPriority(MAX_PRIORITY);
		System.out.println(t.getPriority());
		
		t.start();
	}
}

