class ThreadDemoWithExtends extends Thread
{
	public void run()
	{
		System.out.println("Thread is Working Now!");
	}
	public static void main(String [] args)
	{
		ThreadDemoWithExtends t=new ThreadDemoWithExtends();
		t.start();
	}
}