class YieldThread extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=5;i++)
			{
				Thread.yield();
				System.out.println("Run Method : "+i);	
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public static void main(String [] args)
	{
		try
		{
			YieldThread t=new YieldThread();
			t.start();
		
			for(int i=1;i<=5;i++)
			{
				System.out.println("Main Method : "+i);
				Thread.currentThread().sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}