class Palindrome
{
	public static void main(String [] args)
	{
		String s=args[0];
		char[] str=s.toCharArray();
		int b=str.length-1;
		int c=str.length;
		int flag=0;
		
		for(int a=0;a<c/2;a++)
		{
			if(str[a]==str[b])
			{
				b--;
				continue;
			}
			else
			{
				flag=1;
				System.out.println("Not palindrome");
				break;
			}
		}
		if(flag==0)
		{
			System.out.println("Palindrome");
		}
	}
}