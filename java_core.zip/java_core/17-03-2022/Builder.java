class Builder
{
 public static void main(String [] args)
 {
	 StringBuilder s=new StringBuilder("Yash");
	 System.out.println(s);
	 s.append(" Tecnologies");
	 System.out.println(s);
	 s.insert(0,"Welcome To ");
	 System.out.println(s);
 }
}