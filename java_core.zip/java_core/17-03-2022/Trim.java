class Trim
{
	public static void main(String [] args)
	{
		String s1 = new String("     Hello World");
		s1=s1.trim();
		
		System.out.println(s1);
				
	}
}