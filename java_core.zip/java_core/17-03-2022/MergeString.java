class MergeString
{
	public static void main(String [] args)
	{
		char[] s1=args[0].toCharArray();
		char[] s2=args[1].toCharArray();
		
		for(int a=0;a<s1.length||a<s2.length;a++)
		{
			if (a<s1.length)
			{
				System.out.print(s1[a]);
			}
			if (a<s2.length)
			{
				System.out.print(s2[a]);
			}	
		}
	}
}