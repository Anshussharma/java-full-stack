import java.util.ArrayList;
import java.util.Iterator;
class ArrayListOfMonths
{
	public static void main(String [] args)
	{
		ArrayList<String> arr=new ArrayList<String>();
		arr.add("January");
		arr.add("Febraury");
		arr.add("March");
		arr.add("April");
		arr.add("May");
		arr.add("June");
		arr.add("July");
		arr.add("August");
		arr.add("September");
		arr.add("Octomber");
		arr.add("November");
		arr.add("December");
	
		System.out.println(arr);
		
		for(String s: arr)
		{
			System.out.println(s);
		}
		
		Iterator i=arr.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		
		
	}
}