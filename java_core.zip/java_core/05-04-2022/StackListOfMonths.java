import java.util.Stack;
import java.util.Iterator;
class StackListOfMonths
{
	public static void main(String [] args)
	{
		Stack<String> arr=new Stack<String>();
		arr.add("January");
		arr.add("Febraury");
		arr.add("March");
		arr.add("April");
		arr.add("May");
		arr.add("June");
		arr.add("July");
		arr.add("August");
		arr.add("September");
		arr.add("Octomber");
		arr.add("November");
		arr.add("December");
	
		System.out.println(arr);
	}
}