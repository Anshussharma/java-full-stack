import java.util.ArrayList;
class ArrayListDemo
{
	public static void main(String [] args)
	{
		ArrayList arr=new ArrayList();
		arr.add("Hritik");
		arr.add(20);
		arr.add("Bhopal");
		
		System.out.println(arr);
	}
}