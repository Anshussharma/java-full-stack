import java.util.Scanner;

class VoteEligiblity extends RuntimeException
{
	VoteEligiblity(String s)
	{
		super(s);
	}
}

class ThrowDemo
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age: ");
		int age=sc.nextInt();
		try
		{
			if(age<18)
			{
				throw new VoteEligiblity("Your are not eligible for voting");
			}
			else
			{
				System.out.println("You can Vote");
			}
		}
		catch(VoteEligiblity e)
		{
			e.printStackTrace();
		}
		System.out.println("Normal Termination");
	}
}