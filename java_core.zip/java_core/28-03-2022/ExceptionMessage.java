class ExceptionMessage
{
	public static void main(String [] args)
	{
		try
		{
			System.out.println(100/0);
		}
		catch(ArithmeticException e)
		{
			System.out.println("------------------------------------");
			e.printStackTrace();
			System.out.println("------------------------------------");
			System.out.println(e);
			System.out.println("------------------------------------");
			System.out.println(e.getMessage());
		}
	}
}