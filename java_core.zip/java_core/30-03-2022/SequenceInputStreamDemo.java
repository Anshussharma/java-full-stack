import java.io.*;

class SequenceInputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream f1=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/abc.txt");
		FileInputStream f2=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/xyz.txt");
		SequenceInputStream st=new SequenceInputStream(f1,f2);
		int i;
		while((i=st.read())!=-1)
		{
			System.out.print((char)i);
		}
		st.close();
		f1.close();
		f2.close();
	}
}