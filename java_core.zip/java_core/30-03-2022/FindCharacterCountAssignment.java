import java.io.*;
import java.util.Scanner;

class FindCharacterCountAssignment
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream in=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/yash.txt");
		int count=0;
		int c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter a character to find: ");
		char a=sc.next().charAt(0);
		while((c=in.read())!=-1)
		{
			if(c==(int)a)
			{
				count++;
			}
		}
		System.out.println("It appers: "+count+" times");
		in.close();
		
	}
}