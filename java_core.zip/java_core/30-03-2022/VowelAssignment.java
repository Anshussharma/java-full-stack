import java.io.*;

class VowelAssignment
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream in=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/yash.txt");
		int countA=0;
		int countE=0;
		int countI=0;
		int countO=0;
		int countU=0;
		int c;
		while((c=in.read())!=-1)
		{
			if(c==97||c==65)
			{
				countA++;
			}
			if(c==101||c==69)
			{
				countE++;
			}
			if(c==105||c==73)
			{
				countI++;
			}
			if(c==111||c==79)
			{
				countO++;
			}
			if(c==117||c==85)
			{
				countU++;
			}
			
		}
		System.out.println("No. of A: "+countA);
		System.out.println("No. of E: "+countE);
		System.out.println("No. of I: "+countI);
		System.out.println("No. of O: "+countO);
		System.out.println("No. of U: "+countU);
		in.close();
		
	}
}