import java.io.*;

class DataOutputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		FileOutputStream out=new FileOutputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/abc.txt");
		DataOutputStream dt=new DataOutputStream(out);
		int[] arr=new int[]{72,101,108,108,111,32,119,111,114,108,100};
		for(int a: arr)
			{
				dt.write(a);
			}
		out.close();
		dt.close();
	}
}