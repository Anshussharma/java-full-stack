import java.io.*;

class ByteArrayInputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		byte[] arr=new byte[]{72,101,108,108,111,32,119,111,114,108,100};
		ByteArrayInputStream st=new ByteArrayInputStream(arr);
		int i;
		while((i=st.read())!=-1)
		{
			System.out.print((char)i);
		}
		st.close();
		
	}
}