import java.io.*;

class CountAssignment
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream in=new FileInputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/yash.txt");
		int countLine=0;
		int countWords=0;
		int countCharacters=0;
		int countSpaces=0;
		int c;
		while((c=in.read())!=-1)
		{
			if(c==13)
			{
				countLine++;
			}
			if(c==32||c==13)
			{
				countWords++;
			}
			if(c!=32&&c!=13&&c!=10)
			{
				countCharacters++;
			}
			if(c==32)
			{
				countSpaces++;
			}
			
		}
		System.out.println("No. of Lines: "+countLine);
		System.out.println("No. of Words: "+countWords);
		System.out.println("No. of Characters: "+countCharacters);
		System.out.println("No. of Spaces: "+countSpaces);
		in.close();
		
	}
}