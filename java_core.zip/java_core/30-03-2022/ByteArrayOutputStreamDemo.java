import java.io.*;

class ByteArrayOutputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		FileOutputStream f1=new FileOutputStream("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/30-03-2022/arr.txt");
		ByteArrayOutputStream st=new ByteArrayOutputStream();
		int[] arr=new int[]{72,101,108,108,111,32,119,111,114,108,100};
		for(int a: arr)
			{
				st.write(a);
			}
			st.writeTo(f1);
		st.close();
	}
}