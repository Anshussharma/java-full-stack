class ThisAsArgument
{
    ThisAsArgument()
   {
	   ThisAsArgument a=new ThisAsArgument(this);
   }
   ThisAsArgument(ThisAsArgument a)
   {
	   System.out.println("Hello");
   }
   public static void main(String [] args)
   {
	   ThisAsArgument a=new ThisAsArgument();
   }
}