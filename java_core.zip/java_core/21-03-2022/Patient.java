class Patient
{
	public static void main(String [] args)
	{
		Patient p=new Patient();
		String name="Hritik";
		System.out.println(name+" BMI is: "+p.BMI(0.1397,68));
	}
	double BMI(double heigth,int weight)
	{
		double c=heigth*heigth;
		return weight/c;
	}
}