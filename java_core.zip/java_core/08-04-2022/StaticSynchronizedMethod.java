class BookTicket
{
	static int totalSeats=12;
	static synchronized void bookSeats(int seats)
	{
		if(totalSeats>=seats)
		{
			System.out.println("Ticket Booked Successfully!");
			totalSeats=totalSeats-seats;
			System.out.println("Remaining seats: "+totalSeats);
		}
		else
		{
			System.out.println("Seats are not available: "+totalSeats);
		}
	}
}

class StaticSynchronizedMethod2 extends Thread
{
	static BookTicket b1=new BookTicket();
	public void run()
	{
		b1.bookSeats(8);
	}
}
class StaticSynchronizedMethod extends Thread
{
	static BookTicket b;
	public void run()
	{
		b.bookSeats(8);
	}
	public static void main(String [] args)
	{
		b=new BookTicket();
		StaticSynchronizedMethod t1=new StaticSynchronizedMethod();
		t1.start();
		StaticSynchronizedMethod t2=new StaticSynchronizedMethod();
		t2.start();
		
		StaticSynchronizedMethod2 t3=new StaticSynchronizedMethod2();
		t3.start();
		StaticSynchronizedMethod2 t4=new StaticSynchronizedMethod2();
		t4.start();
		
	}
}