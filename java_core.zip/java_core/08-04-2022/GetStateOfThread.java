class GetStateOfThread extends Thread
{
	public void run()
	{
		try
		{
			for(int i=0;i<5;i++)
			{
				Thread.currentThread().sleep(300);
				System.out.println("I am Thread "+i);
			}
			System.out.println(Thread.currentThread().getState());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String [] args) throws Exception
	{
		GetStateOfThread t=new GetStateOfThread();
		
		t.start();
		t.join();
		
		System.out.println(t.getState());
		
	}
}