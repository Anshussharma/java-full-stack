class ThreadIsInterrupted extends Thread
{
	public void run()
	{
		//System.out.println(Thread.currentThread().isInterrupted());
		try
		{
			//System.out.println(Thread.currentThread().isInterrupted());
			for(int i=1;i<=5;i++)
			{
				System.out.println(Thread.currentThread().isInterrupted());
				System.out.println("I am Thread "+i);
				Thread.currentThread().sleep(300);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String [] args)
	{
		ThreadIsInterrupted t=new ThreadIsInterrupted();
		t.start();
		t.interrupt();
	}
}