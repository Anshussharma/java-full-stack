class BookTicket
{
	int totalSeats=12;
	synchronized void bookSeats(int seats)
	{
		if(totalSeats>=seats)
		{
			System.out.println("Ticket Booked Successfully!");
			totalSeats=totalSeats-seats;
			System.out.println("Remaining seats: "+totalSeats);
		}
		else
		{
			System.out.println("Seats are not available: "+totalSeats);
		}
	}
}

class SynchronizedMethodDemo extends Thread
{
	static BookTicket b;
	public void run()
	{
		b.bookSeats(8);
	}
	public static void main(String [] args)
	{
		b=new BookTicket();
		SynchronizedMethodDemo t1=new SynchronizedMethodDemo();
		t1.start();
		SynchronizedMethodDemo t2=new SynchronizedMethodDemo();
		t2.start();
	}
}