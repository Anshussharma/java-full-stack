class Revenue extends Thread
{
	int total=0;
	public void run()
	{
		synchronized(this)
		{
			for(int i=1;i<=5;i++)
			{
				total=total+400;
			}
			this.notify();
		}
	}
}

class ThreadWaitAndNotify
{
	public static void main(String [] args) throws Exception
	{
		Revenue r=new Revenue(); 
		r.start();
		
		synchronized(r)
		{
			r.wait();
			System.out.println("Total Amount"+r.total);
		}
	}
}