class PrimeNumber
{
  public static void main(String args[]){  
 int num=Integer.parseInt(args[0]);
for(int a=num-1;a>1;a--)
{
if(num%a==0)
{

System.out.println("notprime");
break;
}else
System.out.println("prime");
}
}
 }  
 