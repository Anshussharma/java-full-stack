class Factorial
{
public static void main(String [] args)
{
int num= Integer.parseInt(args[0]);
int total=1;

for(int a=num;a>=1;a--)
{
total=total*a;
}
System.out.println(total);
}
}