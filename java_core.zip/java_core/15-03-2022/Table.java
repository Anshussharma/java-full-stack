class Table
{
public static void main(String [] args)
{
int num= Integer.parseInt(args[0]);

for(int a=1;a<=10;a++)
{
System.out.println(num*a);
}
}
}