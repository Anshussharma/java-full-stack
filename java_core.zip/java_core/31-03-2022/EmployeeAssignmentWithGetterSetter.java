import java.io.*;
import java.util.Scanner;

class Emp implements Serializable
{
	private String empName;
	private String department;
	private String designation;
	private double salary;
	
	public void setEmpName(String empName)
	{
		this.empName=empName;
	}
	
	public String getEmpName()
	{
		return empName;
	}
	
	public void setDepartment(String department)
	{
		this.department=department;
	}
	
	public String getDepartment()
	{
		return department;
	}
	
	public void setDesignation(String designation)
	{
		this.designation=designation;
	}
	
	public String getDesignation()
	{
		return designation;
	}
	
	public void setSalary(double salary)
	{
		this.salary=salary;
	}
	
	public double getSalary()
	{
		return salary;
	}
}

class EmployeeAssignmentWithGetterSetter 
{
	public static void main(String [] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		Emp e=new Emp();
		System.out.println("Please enter employee name: ");
		e.setEmpName(sc.nextLine());
		System.out.println("Please enter employee department: ");
		e.setDepartment(sc.nextLine());
		System.out.println("Please enter employee designation: ");
		e.setDesignation(sc.nextLine());
		System.out.println("Please enter employee salary: ");
		e.setSalary(sc.nextDouble());
		
		File f=new File("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/31-03-2022/abc.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
		e=(Emp)ois.readObject();
		System.out.println("\nEmployee name: "+e.getEmpName());
		System.out.println("Department: "+e.getDepartment());
		System.out.println("Designation: "+e.getDesignation());
		System.out.println("Salary: "+e.getSalary());
		ois.close();		
	}
}