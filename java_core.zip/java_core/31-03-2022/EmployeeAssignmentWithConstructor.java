import java.io.*;
import java.util.Scanner;

class Emp implements Serializable
{
	private String empName;
	private String department;
	private String designation;
	private double salary;
	
	Emp(String empName, String department, String designation, double salary)
	{
		this.empName=empName;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}
	
	public String toString()
	{
		String s="\nEmployee name: "+empName+"\nDepartment: "+department+"\nDesignation: "+designation+"\nSalary: "+salary;
		return s;
	}
}

class EmployeeAssignmentWithConstructor 
{
	public static void main(String [] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please enter employee name: ");
		String name=sc.nextLine();
		System.out.println("Please enter employee department: ");
		String department=sc.nextLine();
		System.out.println("Please enter employee designation: ");
		String designation=sc.nextLine();
		System.out.println("Please enter employee salary: ");
		double salary=sc.nextDouble();
		
		Emp e=new Emp(name,department,designation,salary);
		
		File f=new File("C:/Users/Hritik.Sahu/Desktop/Java Full Stack/31-03-2022/abc.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
		e=(Emp)ois.readObject();
		System.out.println(e);
		ois.close();		
	}
}