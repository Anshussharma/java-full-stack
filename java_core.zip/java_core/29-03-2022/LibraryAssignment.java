import java.util.Scanner;

interface LibraryUser
{
	void registerAccount();
	void requestBook();
}

class KidUsers implements LibraryUser
{
	int age;
	String bookType;
	Scanner sc=new Scanner(System.in);
	public void registerAccount()
	{
		System.out.println("Please enter the age: ");
		age=sc.nextInt();
		if(age<12)
		{
			System.out.println("You have successfully registered under a kids account.");
			KidUsers kid=new KidUsers();
			kid.requestBook();
		}
		else
		{
			System.out.println("Sorry, age must be less than 12 to register as a kid.");
		}
	}
	
	public void requestBook()
	{
		System.out.println("Please enter the book type: ");
		bookType=sc.nextLine();
		if(bookType.equals("Kids"))
		{
			System.out.println("Book issued successfully, please return the book within 10 days.");
		}
		else
		{
			System.out.println("Oops, you are allowed to take only kids books;");
		}
	}
	
}

class AdultUser implements LibraryUser
{
	int age;
	String bookType;
	Scanner sc=new Scanner(System.in);
	public void registerAccount()
	{
		System.out.println("Please enter the age: ");
		age=sc.nextInt();
		if(age>12)
		{
			System.out.println("You have successfully registered under a adult account.");
			AdultUser adult=new AdultUser();
			adult.requestBook();
		}
		else
		{
			System.out.println("Sorry, age must be more than 12 to register as a Adult.");
		}
	}
	
	public void requestBook()
	{
		System.out.println("Please enter the book type: ");
		bookType=sc.nextLine();
		if(bookType.equals("Fiction"))
		{
			System.out.println("Book issued successfully, please return the book within 7 days.");
		}
		else
		{
			System.out.println("Oops, you are allowed to take only adult books;");
		}
	}
}

class LibraryAssignment
{
	public static void main(String [] args)
	{
		System.out.println("Press 1 for Kid");
		System.out.println("Press 2 for Adult");
		
		Scanner sc =new Scanner(System.in);
		switch(sc.nextInt())
		{
			case 1: KidUsers kid=new KidUsers();
					kid.registerAccount();
					break;
					
			case 2: AdultUser adult=new AdultUser();
					adult.registerAccount();
					break;
					
		}
	}
}