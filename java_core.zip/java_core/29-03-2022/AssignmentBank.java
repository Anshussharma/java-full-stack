abstract class GeneralBank
{
	abstract double getSavingsInterestRate();
    abstract double getFixedInterestRate();
}

class ICICIBank extends GeneralBank
{
	double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedInterestRate()
	{
		return 8.5;
	}
}

class SBIBank extends GeneralBank
{
	double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedInterestRate()
	{
		return 7;
	}
}

class AssignmentBank
{
	public static void main(String [] args)
	{
		ICICIBank i=new ICICIBank();
		SBIBank s=new SBIBank();
		System.out.println("ICICI Bank saving acount: "+i.getSavingsInterestRate());
		System.out.println("ICICI Bank fixed acount: "+i.getFixedInterestRate());
		System.out.println("\nSBI Bank saving acount: "+s.getSavingsInterestRate());
		System.out.println("SBI Bank fixed acount: "+s.getFixedInterestRate());
		
		GeneralBank g1=new ICICIBank();
		GeneralBank g2=new SBIBank();
		System.out.println("\nGeneral Bank saving acount: "+g1.getSavingsInterestRate());
		System.out.println("General Bank fixed acount: "+g2.getFixedInterestRate());
	}
	
}