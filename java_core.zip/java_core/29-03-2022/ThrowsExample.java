class DemoException
{
  void show() throws ClassNotFoundException
  {
	  Class.forName("Hello");
  }
}
class ThrowsExample 
{
	public static void main(String [] args) throws ClassNotFoundException
	{
		DemoException d=new DemoException();
		d.show();
	}
}