package Game;
//import Game.Dragon;
//import Game.Dragon2;
public class Kill {

    public static void main(String[] args) {
        Dragon d1 = new Dragon("fire",100);
        Dragon2 d2 = new Dragon2("fire balls",100,true);
        System.out.println(d2.getLife());
        System.out.println(d2.getPower());
    }

}